let stringUser = prompt('Введите вашу информацию');
console.log('Занимает ' + stringUser.length + ' места' );
let length = +prompt('Введите длину строки!');
let symbolic = prompt('Введите символ которым наполнится свободное место строки!');
let left = false
console.log(stringUser, length, symbolic);
function padString (string, stringLength, symbol, left = false) {
    if(symbolic.length === 1) {
        let newSymbolCount = length - stringUser.length;
        console.log(newSymbolCount);
        // Добавил переменную для флага и посчитал кол-во свободного места в строке
        let add = symbol.repeat(newSymbolCount);
        console.log(add);
        // Добавил переменную, которая будет добавлять символы в свободное место
    
        if(left = true) {
            let added = add += string;
            console.log(added);
            return padString = added;
        } else if(left = false) {
            let right = string += add;
            console.log(right);
            return padString = right;
        }
    } else {
        throw new Error('Больше одного символа!');
    }    

}
console.log(padString(stringUser, length, symbolic));